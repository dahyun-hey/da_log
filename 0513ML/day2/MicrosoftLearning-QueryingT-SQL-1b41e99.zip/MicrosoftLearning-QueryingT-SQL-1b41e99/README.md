![Querying with Transact-SQL]
(https://www.edx.org/sites/default/files/styles/course_video_banner/public/course/image/featured-card/dat201x_thumbnail.jpg)

***

This repository contains the lab files and handouts for the Microsoft course *Querying with Transact-SQL*. Sign up for this free course on [edX](https://www.edx.org/course/querying-transact-sql-microsoft-dat201x-0) or [Microsoft Virtual Academy](https://mva.microsoft.com/en-US/training-courses/querying-with-transact-sql-10530).

If you are completing the course on Microsoft Virtual Academy (MVA), follow the instructions in the MVA Setup Guide to prepare for the labs. If you are completing the course in edX, follow the instructions in the Getting Started with DAT201x document.
